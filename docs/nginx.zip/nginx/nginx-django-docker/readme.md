uwsgi --http :8000 --wsgi-file test.py
